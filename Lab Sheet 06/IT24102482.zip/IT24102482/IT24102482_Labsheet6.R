setwd("C:\\Users\\MSI\\Desktop\\IT24102482_Lab6")

#Q1
#1 - Binomial Distribution

#2
pbinom(46, 50, 0.85, lower.tail = FALSE)

#Q2
#1 - number of customer calls per hour

#2 - posson distribution

#3
dpois(15,12)
