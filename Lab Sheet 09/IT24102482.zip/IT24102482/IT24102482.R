setwd("C:\\Users\\MSI\\Desktop\\IT24102482")

#Q1
baking_time <- rnorm(25, mean = 45, sd = 2)
baking_time

#Q2
t_test_result <- t.test(baking_time, mu = 46, alternative = "less")
t_test_result


t_statistic <- t_test_result$statistic
p_value <- t_test_result$p.value
conf_interval <- t_test_result$conf.int

t_statistic
p_value
conf_interval